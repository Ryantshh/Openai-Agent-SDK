# `Result`

::: agents.voice.result
