---
name: Question
about: Questions about the SDK
title: ''
labels: question
assignees: ''

---

### Please read this first

- **Have you read the docs?**[Agents SDK docs](https://openai.github.io/openai-agents-python/)
- **Have you searched for related issues?** Others may have had similar requests

### Question
Describe your question. Provide details if available.
